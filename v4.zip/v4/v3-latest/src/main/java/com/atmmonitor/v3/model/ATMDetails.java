package com.atmmonitor.v3.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;

@Entity
@Table(name = "ATMDetails")
public class ATMDetails {
    
  
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ATMLogId")
    private Integer atmLogId;
    
    @Column(name = "ATMId", length = 100)
    private String atmId;
    
   
    @Column(name = "ATMName", length = 100)
    private String atmName;
    
    @NotNull
    @Column(name = "status", length = 20, nullable = false)
    private String status;
  
    @Column(name = "LocationId", length = 255)
    private String location;
   
    @Column(name = "temp_c_th")
    private Float temperatureCelsiusThreshold;
    
    
    @Column(name = "cash_t_th", precision = 18, scale = 2)
    private BigDecimal cashTotalThreshold;
    
    
    public ATMDetails() {
    }
    
   
    public ATMDetails(String atmId, String atmName, String location) {
        this.atmId = atmId;
        this.atmName = atmName;
        this.location = location;
    }
    
    // Getters and Setters
    
    public Integer getAtmLogId() {
        return atmLogId;
    }
    
    public void setAtmLogId(Integer atmLogId) {
        this.atmLogId = atmLogId;
    }
    
    public String getAtmId() {
        return atmId;
    }
    
    public void setAtmId(String atmId) {
        this.atmId = atmId;
    }
    
    public String getAtmName() {
        return atmName;
    }
    
    public void setStatus(String status) {
        this.status = status; 
    }

    public String getStatus() {
        return status;
    }
    
    public void setAtmName(String atmName) {
        this.atmName = atmName;
    }
    
    public String getLocation() {
        return location;
    }
    
    public void setLocation(String location) {
        this.location = location;
    }
    
    public Float getTemperatureCelsiusThreshold() {
        return temperatureCelsiusThreshold;
    }
    
    public void setTemperatureCelsiusThreshold(Float temperatureCelsiusThreshold) {
        this.temperatureCelsiusThreshold = temperatureCelsiusThreshold;
    }
    
    public BigDecimal getCashTotalThreshold() {
        return cashTotalThreshold;
    }
    
    public void setCashTotalThreshold(BigDecimal cashTotalThreshold) {
        this.cashTotalThreshold = cashTotalThreshold;
    }
    
    @Override
    public String toString() {
        return "ATMDetails{" +
                "atmLogId=" + atmLogId +
                ", atmId='" + atmId + '\'' +
                ", atmName='" + atmName + '\'' +
                ", location='" + location + '\'' +
                ", temperatureCelsiusThreshold=" + temperatureCelsiusThreshold +
                ", cashTotalThreshold=" + cashTotalThreshold +
                '}';
    }
}
