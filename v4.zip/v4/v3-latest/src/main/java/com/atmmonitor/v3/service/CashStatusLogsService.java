package com.atmmonitor.v3.service;

// import java.math.BigDecimal;
// import java.time.LocalDateTime;
import java.util.List;
//import java.util.Optional;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

//import com.atmmonitor.v3.dto.CashStatusDto;
import com.atmmonitor.v3.model.CashStatusLogs;
import com.atmmonitor.v3.repository.CashStatusLogsRepository;

/**
 * Service class for CashStatusLogs that implements business logic and interacts with the repository.
 */
@Service
@Transactional
public class CashStatusLogsService {

    private final CashStatusLogsRepository cashStatusLogsRepository;

    public CashStatusLogsService(CashStatusLogsRepository cashStatusLogsRepository) {
        this.cashStatusLogsRepository = cashStatusLogsRepository;
    }


    // public List<CashStatusLogs> getAllCashStatusLogs() {
    //     return cashStatusLogsRepository.findAll();
    // }

    // public Optional<CashStatusLogs> getCashStatusLogsById(Integer id) {
    //     return cashStatusLogsRepository.findById(id);
    // }

    // public CashStatusLogs saveCashStatusLogs(CashStatusLogs cashStatusLog) {
    //     cashStatusLog.calculateTotalAmount();
    //     return cashStatusLogsRepository.save(cashStatusLog);
    // }


    // public CashStatusLogs processIoTCashStatusData(CashStatusDto cashStatusDto) {
    //     CashStatusLogs cashStatusLog = new CashStatusLogs();
    //     cashStatusLog.setConnectionDeviceId(cashStatusDto.getConnectionDeviceId());  // Ensure this method exists
    //     //cashStatusLog.setStatus(cashStatusDto.getStatus());
    //     cashStatusLog.setNotes100(cashStatusDto.getNotes100());
    //     cashStatusLog.setNotes200(cashStatusDto.getNotes200());
    //     cashStatusLog.setNotes500(cashStatusDto.getNotes500());
        
    //     cashStatusLog.setTimestamp(LocalDateTime.now());
        
    //     cashStatusLog.calculateTotalAmount();
        
    //     return cashStatusLogsRepository.save(cashStatusLog);
    // }


    // public void deleteCashStatusLogs(Integer id) {
    //     cashStatusLogsRepository.deleteById(id);
    // }

    /**
     * Working
     */
    public List<CashStatusLogs> getCashStatusLogsByDeviceId(String connectionDeviceId) {
        return cashStatusLogsRepository.findByConnectionDeviceId(connectionDeviceId);
    }

    /**
    public List<CashStatusLogs> getCashStatusLogsByStatus(String status) {
        return cashStatusLogsRepository.findByStatus(status);
    }
    
   
    public List<CashStatusLogs> getLatestCashStatusByDevice() {
        return cashStatusLogsRepository.findLatestCashStatusLogsByDevice();
    }

    public List<CashStatusLogs> getDevicesWithLowCash(BigDecimal threshold) {
        return cashStatusLogsRepository.findDevicesWithLowCash(threshold);
    }

    public List<CashStatusLogs> getDevicesNeedingReplenishment(
            Integer notes100Threshold, Integer notes200Threshold, Integer notes500Threshold) {
        return cashStatusLogsRepository.findDevicesNeedingReplenishment(
                notes100Threshold, notes200Threshold, notes500Threshold);
    }

    public List<CashStatusLogs> getCashStatusLogsByTimePeriod(LocalDateTime startTime, LocalDateTime endTime) {
        return cashStatusLogsRepository.findByTimestampBetween(startTime, endTime);
    }
    */
}