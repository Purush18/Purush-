package com.atmmonitor.v3.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

@Configuration
@EnableConfigurationProperties
public class ApplicationConfig {
    @Bean
    @Primary
    public ObjectMapper objectMapper() {
            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.registerModule(new JavaTimeModule());
            objectMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
            return objectMapper;
        }
    
    @Bean
    @ConfigurationProperties(prefix = "azure.servicebus")
    public ServiceBusProperties serviceBusProperties() {
        return new ServiceBusProperties();
    }
       
    public static class ServiceBusProperties {
        private String connectionString;
        private String topicName;
        private String subscriptionName;
        
        public String getConnectionString() {
            return connectionString;
        }
        
        public void setConnectionString(String connectionString) {
            this.connectionString = connectionString;
        }
        
        public String getTopicName() {
            return topicName;
        }
        
        public void setTopicName(String topicName) {
            this.topicName = topicName;
        }
        
        public String getSubscriptionName() {
            return subscriptionName;
        }
        
        public void setSubscriptionName(String subscriptionName) {
            this.subscriptionName = subscriptionName;
        }
    }
}
