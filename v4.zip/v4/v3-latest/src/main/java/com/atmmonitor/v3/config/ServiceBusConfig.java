package com.atmmonitor.v3.config;

import com.azure.messaging.servicebus.ServiceBusClientBuilder;
import com.azure.messaging.servicebus.ServiceBusReceiverClient;
import com.azure.messaging.servicebus.ServiceBusSenderClient;
//import com.fasterxml.jackson.databind.ObjectMapper;
//import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

@Configuration
public class ServiceBusConfig {

    @Autowired
    private ApplicationConfig.ServiceBusProperties serviceBusProperties;
    
    @Bean
    public ServiceBusSenderClient serviceBusSenderClient() {
        return new ServiceBusClientBuilder()
                .connectionString(serviceBusProperties.getConnectionString())
                .sender()
                .topicName(serviceBusProperties.getTopicName())
                .buildClient();
    }

    @Bean
    public ServiceBusReceiverClient serviceBusReceiverClient() {
        return new ServiceBusClientBuilder()
                .connectionString(serviceBusProperties.getConnectionString())
                .receiver()
                .topicName(serviceBusProperties.getTopicName())
                .subscriptionName(serviceBusProperties.getSubscriptionName())
                .buildClient();
    }
    
    /**
     * Service Bus Client Builder to be used by the AutomaticServiceBusProcessor
     * to create the processor client with the correct message and error handlers
     */
    @Bean
    public ServiceBusClientBuilder serviceBusClientBuilder() {
        return new ServiceBusClientBuilder()
                .connectionString(serviceBusProperties.getConnectionString());
    }

    @Bean
    public TaskExecutor taskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(5);
        executor.setMaxPoolSize(10);
        executor.setQueueCapacity(25);
        return executor;
    }
        
    
}
