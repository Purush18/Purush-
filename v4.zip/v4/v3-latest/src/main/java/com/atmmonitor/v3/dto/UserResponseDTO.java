package com.atmmonitor.v3.dto;

public class UserResponseDTO {
    private String message;
    private String role;
    private String redirectPath;

    public UserResponseDTO(String message, String role, String redirectPath) {
        this.message = message;
        this.role = role;
        this.redirectPath = redirectPath;
    }

    public String getMessage() {
        return message;
    }

    public String getRole() {
        return role;
    }

    public String getRedirectPath() {
        return redirectPath;
    }
}
