package com.atmmonitor.v3.repository;

//import java.math.BigDecimal;
//import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.data.jpa.repository.Query;
//import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.atmmonitor.v3.model.CashStatusLogs;


@Repository
public interface CashStatusLogsRepository extends JpaRepository<CashStatusLogs, Integer> {
    
//     @Query("SELECT c FROM CashStatusLogs c")
//     List<CashStatusLogs> getAllCashStatusLogs();
    


//     @Query("SELECT c FROM CashStatusLogs c")
//     List<CashStatusLogs> saveAllCashStatusLogs();
    

//     @Query(value = "INSERT INTO CashStatusLogs (connection_device_id, timestamp, notes100, notes200, notes500, totalamount) " +
//            "VALUES (:#{#log.connectionDeviceId}, :#{#log.timestamp}, :#{#log.notes100}, :#{#log.notes200}, :#{#log.notes500}, :#{#log.totalamount})", 
//            nativeQuery = true)
//     CashStatusLogs insertCashStatusLog(@Param("log") CashStatusLogs log);

    // Working
    List<CashStatusLogs> findByConnectionDeviceId(String connectionDeviceId);
    
//     List<CashStatusLogs> findByTotalamountGreaterThan(BigDecimal threshold);
    
//     List<CashStatusLogs> findByTimestampBetween(LocalDateTime startTime, LocalDateTime endTime);
    
//     @Query("SELECT c FROM CashStatusLogs c WHERE c.notes100 < :threshold OR c.notes200 < :threshold OR c.notes500 < :threshold")
//     List<CashStatusLogs> findByLowNotes(@Param("threshold") Integer threshold);
    
//     @Query("SELECT c FROM CashStatusLogs c WHERE c.timestamp = " +
//            "(SELECT MAX(c2.timestamp) FROM CashStatusLogs c2 WHERE c2.connectionDeviceId = c.connectionDeviceId)")
//     List<CashStatusLogs> findLatestCashStatusLogsByDevice();
    
//     @Query("SELECT c FROM CashStatusLogs c WHERE c.timestamp = " +
//            "(SELECT MAX(c2.timestamp) FROM CashStatusLogs c2 WHERE c2.connectionDeviceId = c.connectionDeviceId) " +
//            "AND c.totalamount < :amount")
//     List<CashStatusLogs> findDevicesWithLowCash(@Param("amount") BigDecimal amount);
    
//     @Query("SELECT AVG(c.totalamount) FROM CashStatusLogs c " +
//            "WHERE c.connectionDeviceId = :connectionDeviceId AND c.timestamp BETWEEN :startTime AND :endTime")
//     BigDecimal findAverageTotalAmountByDevice(
//         @Param("connectionDeviceId") String connectionDeviceId, 
//         @Param("startTime") LocalDateTime startTime, 
//         @Param("endTime") LocalDateTime endTime
//     );
    
//     @Query("SELECT c FROM CashStatusLogs c WHERE c.timestamp = " +
//            "(SELECT MAX(c2.timestamp) FROM CashStatusLogs c2 WHERE c2.connectionDeviceId = c.connectionDeviceId) " +
//            "AND (c.notes100 < :notes100Threshold OR c.notes200 < :notes200Threshold OR c.notes500 < :notes500Threshold)")
//     List<CashStatusLogs> findDevicesNeedingReplenishment(
//         @Param("notes100Threshold") Integer notes100Threshold,
//         @Param("notes200Threshold") Integer notes200Threshold,
//         @Param("notes500Threshold") Integer notes500Threshold
//     );
}