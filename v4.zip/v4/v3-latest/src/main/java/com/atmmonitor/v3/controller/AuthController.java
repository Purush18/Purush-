package com.atmmonitor.v3.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.atmmonitor.v3.model.User;
import com.atmmonitor.v3.repository.UserRepository;
import com.atmmonitor.v3.dto.UserResponseDTO;
//import org.springframework.validation.annotation.Validated;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import java.util.HashMap;
import java.util.Map;

@RestController 
@RequestMapping("/auth")
public class AuthController {

    private final UserRepository userRepository;
    private final BCryptPasswordEncoder passwordEncoder;

    public AuthController(UserRepository userRepository, BCryptPasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody User user) {
        try{
        User existingUser = userRepository.findByEmail(user.getEmail());
        if (existingUser != null && passwordEncoder.matches(user.getPassword(), existingUser.getPassword())) {
            String redirectPath = "/dashboard"; // Default path
            
            
            if ("admin".equals(existingUser.getRole())) {
                redirectPath = "/admin-dashboard.html";
            } else if ("techie".equals(existingUser.getRole())) {
                redirectPath = "/techie-dashboard.html";
            }

           
            UserResponseDTO responseDTO = new UserResponseDTO(
                "Login successful",
                existingUser.getRole(),
                redirectPath
            );

            return ResponseEntity.ok(responseDTO);
        } else {
            UserResponseDTO errorResponse = new UserResponseDTO(
                "Invalid credentials",
                null,
                null
            );
            return ResponseEntity.status(401).body(errorResponse);
        }
    } catch (Exception e) {
        UserResponseDTO errorResponse = new UserResponseDTO(
            "Invalid credentials",
            null,
            null
        );
        return ResponseEntity.status(401).body(errorResponse);
    }


    }

    @PostMapping("/signup")
    public ResponseEntity<?> signup(@RequestBody Map<String, String> request) {
        // Extract fields from request
        String email = request.get("email");
        String password = request.get("password");
        String role = request.get("role");
        String securityQuestion = request.get("securityQuestion");  // Updated to match frontend
        String securityAnswer = request.get("securityAnswer");      // Updated to match frontend
        
        System.out.println("Received request: " + request);  // Debug output
        
        // Validation checks
        if (email == null || password == null || securityQuestion == null || securityAnswer == null) {
            System.out.println("Missing required fields. email=" + email + 
                               ", securityQuestion=" + securityQuestion + 
                               ", securityAnswer=" + securityAnswer);
            
            UserResponseDTO errorResponse = new UserResponseDTO(
                "Missing required fields", 
                null,
                null
            );
            return ResponseEntity.status(400).body(errorResponse);
        }
        
        if (userRepository.findByEmail(email) != null) {
            UserResponseDTO errorResponse = new UserResponseDTO(
                "Email already exists", 
                null,
                null
            );
            return ResponseEntity.status(400).body(errorResponse);
        }
        
        try {
            // Create a new user
            User user = new User();
            user.setEmail(email);
            
            // Set role with validation
            if (role == null || role.isEmpty()) {
                user.setRole("user");
            } else {
                user.setRole(role);
            }
            
            // Password encryption
            String encryptedPassword = passwordEncoder.encode(password);
            user.setPassword(encryptedPassword);
            
            // Set security question fields
            user.setSecurityQuestionValue(securityQuestion);
            
            // Encrypt security answer like a password
            String encryptedAnswer = passwordEncoder.encode(securityAnswer);
            user.setSecurityAnswerValue(encryptedAnswer);
            
            // Save to DB
            userRepository.save(user);
            
            UserResponseDTO successResponse = new UserResponseDTO(
                "Signup successful",
                user.getRole(),
                "/login"  
            );
            return ResponseEntity.ok(successResponse);
        } catch (Exception e) {
            UserResponseDTO errorResponse = new UserResponseDTO(
                "Error during signup: " + e.getMessage(),
                null,
                null
            );
            return ResponseEntity.status(500).body(errorResponse);
        }
    }

    /**
     * Endpoint to retrieve a user's security question
     */
    @GetMapping("/get-security-question")
    public ResponseEntity<?> getSecurityQuestion(@RequestParam String email) {
        try {
            User user = userRepository.findByEmail(email);
            
            if (user == null) {
                Map<String, String> response = new HashMap<>();
                response.put("message", "Email not found");
                return ResponseEntity.status(404).body(response);
            }
            
            // Get the security question from the user
            String securityQuestion = user.getSecurityQuestionValue();
            
            // Convert security question value to actual question text
            String questionText = getQuestionText(securityQuestion);
            
            Map<String, String> response = new HashMap<>();
            response.put("securityQuestion", questionText);
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, String> response = new HashMap<>();
            response.put("message", "Error retrieving security question: " + e.getMessage());
            return ResponseEntity.status(500).body(response);
        }
    }
    
    /**
     * Endpoint to verify a user's security answer
     */
    @PostMapping("/verify-security-answer")
    public ResponseEntity<?> verifySecurityAnswer(@RequestBody Map<String, String> request) {
        try {
            String email = request.get("email");
            String answer = request.get("answer");
            
            User user = userRepository.findByEmail(email);
            
            if (user == null) {
                Map<String, String> response = new HashMap<>();
                response.put("message", "User not found");
                return ResponseEntity.status(404).body(response);
            }
            
            // Compare answers using password encoder (secure comparison)
            if (answer != null && passwordEncoder.matches(answer, user.getSecurityAnswerValue())) {
                Map<String, String> response = new HashMap<>();
                response.put("message", "Security answer verified");
                return ResponseEntity.ok(response);
            } else {
                Map<String, String> response = new HashMap<>();
                response.put("message", "Incorrect security answer");
                return ResponseEntity.status(400).body(response);
            }
        } catch (Exception e) {
            Map<String, String> response = new HashMap<>();
            response.put("message", "Error verifying security answer: " + e.getMessage());
            return ResponseEntity.status(500).body(response);
        }
    }
    
    /**
     * Endpoint to reset a user's password
     */
    @PostMapping("/reset-password")
    public ResponseEntity<?> resetPassword(@RequestBody Map<String, String> request) {
        try {
            String email = request.get("email");
            String password = request.get("password");
            
            User user = userRepository.findByEmail(email);
            
            if (user == null) {
                Map<String, String> response = new HashMap<>();
                response.put("message", "User not found");
                return ResponseEntity.status(404).body(response);
            }
            
            // Update the user's password
            String encryptedPassword = passwordEncoder.encode(password);
            user.setPassword(encryptedPassword);
            userRepository.save(user);
            
            Map<String, String> response = new HashMap<>();
            response.put("message", "Password reset successful");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, String> response = new HashMap<>();
            response.put("message", "Error resetting password: " + e.getMessage());
            return ResponseEntity.status(500).body(response);
        }
    }
    
    /**
     * Helper method to convert security question value to text
     */
    private String getQuestionText(String questionValue) {
        switch (questionValue) {
            case "motherMaiden":
                return "What is your mother's maiden name?";
            case "firstPet":
                return "What was the name of your first pet?";
            case "firstCar":
                return "What was the model of your first car?";
            default:
                return questionValue; // Return as is if not found
        }
    }
}