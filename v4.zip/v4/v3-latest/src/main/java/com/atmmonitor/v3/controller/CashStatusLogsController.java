package com.atmmonitor.v3.controller;

//import java.math.BigDecimal;
//import java.time.LocalDateTime;
import java.util.List;
//import java.util.Optional;

//import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

//import com.atmmonitor.v3.dto.CashStatusDto;
import com.atmmonitor.v3.model.CashStatusLogs;
import com.atmmonitor.v3.service.CashStatusLogsService;
import com.atmmonitor.v3.service.IoTHubService;


@RestController
@RequestMapping("/api/cash-status")
public class CashStatusLogsController {

    private final CashStatusLogsService cashStatusLogsService;
    //private final IoTHubService ioTHubService;

    public CashStatusLogsController(CashStatusLogsService cashStatusLogsService, IoTHubService ioTHubService) {
        this.cashStatusLogsService = cashStatusLogsService;
        //this.ioTHubService = ioTHubService;
    }

    
    // @GetMapping
    // public ResponseEntity<List<CashStatusLogs>> getAllCashStatusLogs() {
    //     List<CashStatusLogs> cashStatusLogs = cashStatusLogsService.getAllCashStatusLogs();
    //     return new ResponseEntity<>(cashStatusLogs, HttpStatus.OK);
    // }

   
    // @PostMapping("/iot-data")
    // public ResponseEntity<?> processIoTData(@RequestBody CashStatusDto cashStatusDto) {
    //     // Validate if this is a cash type message
    //     if (!"cash".equalsIgnoreCase(cashStatusDto.getType())) {
    //         return new ResponseEntity<>("Invalid data type. Must be 'cash'.", HttpStatus.BAD_REQUEST);
    //     }
        
    //     try {
    //         // Send data to IoT Hub
    //         String iotHubStatus = ioTHubService.sendCashStatusData(
    //             cashStatusDto.getConnectionDeviceId(),
    //             cashStatusDto.getNotes100(),
    //             cashStatusDto.getNotes200(),
    //             cashStatusDto.getNotes500()
    //             //cashStatusDto.getStatus()
    //         );
            
    //         return new ResponseEntity<>("Data sent to IoT Hub successfully. Status: " + iotHubStatus, HttpStatus.OK);
    //     } catch (IllegalArgumentException e) {
    //         return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
    //     } catch (Exception e) {
    //         e.printStackTrace();
    //         return new ResponseEntity<>("Error sending data to IoT Hub: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
    //     }
    // }

   
    // @GetMapping("/{id}")
    // public ResponseEntity<CashStatusLogs> getCashStatusLogById(@PathVariable Integer id) {
    //     Optional<CashStatusLogs> cashStatusLog = cashStatusLogsService.getCashStatusLogsById(id);
    //     return cashStatusLog.map(value -> new ResponseEntity<>(value, HttpStatus.OK))
    //             .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    // }

    /* Working */
    @GetMapping("/device/{connectionDeviceId}")
    public ResponseEntity<List<CashStatusLogs>> getCashStatusLogsByDeviceId(@PathVariable String connectionDeviceId) {
        List<CashStatusLogs> cashStatusLogs = cashStatusLogsService.getCashStatusLogsByDeviceId(connectionDeviceId);
        return new ResponseEntity<>(cashStatusLogs, HttpStatus.OK);
    }

    
    // @GetMapping("/status/{status}")
    // public ResponseEntity<List<CashStatusLogs>> getCashStatusLogsByStatus(@PathVariable String status) {
    //     List<CashStatusLogs> cashStatusLogs = cashStatusLogsService.getCashStatusLogsByStatus(status);
    //     return new ResponseEntity<>(cashStatusLogs, HttpStatus.OK);
    // }
    
    
    // @GetMapping("/latest")
    // public ResponseEntity<List<CashStatusLogs>> getLatestCashStatusByDevice() {
    //     List<CashStatusLogs> latestLogs = cashStatusLogsService.getLatestCashStatusByDevice();
    //     return new ResponseEntity<>(latestLogs, HttpStatus.OK);
    // }

   
    // @GetMapping("/low-cash")
    // public ResponseEntity<List<CashStatusLogs>> getDevicesWithLowCash(
    //         @RequestParam(defaultValue = "10000") BigDecimal threshold) {
    //     List<CashStatusLogs> lowCashDevices = cashStatusLogsService.getDevicesWithLowCash(threshold);
    //     return new ResponseEntity<>(lowCashDevices, HttpStatus.OK);
    // }

   
    // @GetMapping("/need-replenishment")
    // public ResponseEntity<List<CashStatusLogs>> getDevicesNeedingReplenishment(
    //         @RequestParam(defaultValue = "50") Integer notes100Threshold,
    //         @RequestParam(defaultValue = "50") Integer notes200Threshold,
    //         @RequestParam(defaultValue = "50") Integer notes500Threshold) {
    //     List<CashStatusLogs> devicesNeedingReplenishment = cashStatusLogsService.getDevicesNeedingReplenishment(
    //             notes100Threshold, notes200Threshold, notes500Threshold);
    //     return new ResponseEntity<>(devicesNeedingReplenishment, HttpStatus.OK);
    // }

   
    // @GetMapping("/period")
    // public ResponseEntity<List<CashStatusLogs>> getCashStatusLogsByTimePeriod(
    //         @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startTime,
    //         @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endTime) {
    //     List<CashStatusLogs> periodLogs = cashStatusLogsService.getCashStatusLogsByTimePeriod(startTime, endTime);
    //     return new ResponseEntity<>(periodLogs, HttpStatus.OK);
    // }
}