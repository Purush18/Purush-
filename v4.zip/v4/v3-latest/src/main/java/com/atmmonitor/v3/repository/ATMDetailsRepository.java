package com.atmmonitor.v3.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.atmmonitor.v3.model.ATMDetails;

import java.util.List;
import java.util.Optional;

@Repository
public interface ATMDetailsRepository extends JpaRepository<ATMDetails, Integer> {
    
    // Working
    Optional<ATMDetails> findByAtmId(String atmId);
    
    // List<ATMDetails> findByAtmNameContaining(String atmName);
    
    // List<ATMDetails> findByLocationContaining(String location);
    
    // @Query("SELECT a.atmId FROM ATMDetails a")
    // List<String> findAllAtmIds();
    
    // Working
    @Query(value = """
        SELECT
            a.ATMId,
            a.ATMName,
            a.LocationId,
            a.status,
            c.totalamount,
            c.notes100,
            c.notes200,
            c.notes500,
            NULL AS cashStatus,
            t.temperature_kvalue,
            t.temperature_cvalue,
            NULL AS tempStatus,
            COALESCE(c.timestamp, t.timestamp) AS lastUpdated,
            a.temp_c_th,
            a.cash_t_th,
            l.Address,
            l.State
        FROM
            ATMDetails a
        LEFT JOIN 
            Location l ON a.LocationId = l.LocationId
        LEFT JOIN
            (SELECT
                connectionDeviceId,
                totalamount,
                notes100,
                notes200,
                notes500,
                timestamp,
                ROW_NUMBER() OVER (PARTITION BY connectionDeviceId ORDER BY timestamp DESC) as rn
             FROM CashStatusLogs) c ON a.ATMId = c.connectionDeviceId AND c.rn = 1
        LEFT JOIN
            (SELECT
                connectionDeviceId,
                temperature_kvalue,
                temperature_cvalue,
                timestamp,
                ROW_NUMBER() OVER (PARTITION BY connectionDeviceId ORDER BY timestamp DESC) as rn
             FROM TemperatureLogs) t ON a.ATMId = t.connectionDeviceId AND t.rn = 1
        WHERE
            a.ATMId = :atmId
        """, nativeQuery = true)
    List<Object[]> getATMDetailsWithStatus(@Param("atmId") String atmId);
    
    // Working 
    @Query(value = """
        SELECT
            a.ATMId,
            a.ATMName,
            a.LocationId,
            a.status,
            c.totalamount,
            c.notes100,
            c.notes200,
            c.notes500,
            NULL AS cashStatus,
            t.temperature_kvalue,
            t.temperature_cvalue,
            NULL AS tempStatus,
            COALESCE(c.timestamp, t.timestamp) AS lastUpdated,
            a.temp_c_th,
            a.cash_t_th,
            l.Address,
            l.State
        FROM
            ATMDetails a
        LEFT JOIN 
            Location l ON a.LocationId = l.LocationId
        LEFT JOIN
            (SELECT
                connectionDeviceId,
                totalamount,
                notes100,
                notes200,
                notes500,
                timestamp,
                ROW_NUMBER() OVER (PARTITION BY connectionDeviceId ORDER BY timestamp DESC) as rn
             FROM CashStatusLogs) c ON a.ATMId = c.connectionDeviceId AND c.rn = 1
        LEFT JOIN
            (SELECT
                connectionDeviceId,
                temperature_kvalue,
                temperature_cvalue,
                timestamp,
                ROW_NUMBER() OVER (PARTITION BY connectionDeviceId ORDER BY timestamp DESC) as rn
             FROM TemperatureLogs) t ON a.ATMId = t.connectionDeviceId AND t.rn = 1
        """, nativeQuery = true)
    List<Object[]> getAllATMDetailsWithStatus();
    
    // @Query("SELECT a.atmId, a.atmName FROM ATMDetails a")
    // List<Object[]> findAllAtmIdsWithNames();
    
    // @Query("SELECT a.atmId, a.atmName, a.location, a.status FROM ATMDetails a")
    // List<Object[]> findAllAtmIdsWithDetails();
    
    // @Query(nativeQuery = true, value = 
    //     "SELECT DISTINCT a.ATMId " +
    //     "FROM ATMDetails a " +
    //     "LEFT JOIN CashStatusLogs c ON a.ATMId = c.connectionDeviceId " +
    //     "LEFT JOIN TemperatureLogs t ON a.ATMId = t.connectionDeviceId " +
    //     "WHERE " +
    //     "    a.status = 'online' " +
    //     "GROUP BY a.ATMId")
    // List<String> findActiveAtmIds();
    // @Query("""
    //     SELECT a
    //     FROM ATMDetails a
    //     WHERE a.location = :locationId
    // """)
    // List<ATMDetails> findATMsByLocationId(@Param("locationId") String locationId);

    // @Query("""
    //         SELECT a
    //         FROM ATMDetails a
    //         JOIN Location l ON a.location = l.locationId
    //         WHERE l.city = :city
    //     """)
    // List<ATMDetails> findATMsByCity(@Param("city") String city);


    // Working
    @Query(value = """
        SELECT
            a.ATMId,
            a.ATMName,
            a.LocationId,
            a.status,
            c.totalamount,
            c.notes100,
            c.notes200,
            c.notes500,
            NULL AS cashStatus,
            t.temperature_kvalue,
            t.temperature_cvalue,
            NULL AS tempStatus,
            COALESCE(c.timestamp, t.timestamp) AS lastUpdated,
            a.temp_c_th,
            a.cash_t_th,
            l.Address,
            l.State
        FROM
            ATMDetails a
        LEFT JOIN
            (SELECT
                connectionDeviceId,
                totalamount,
                notes100,
                notes200,
                notes500,
                timestamp,
                ROW_NUMBER() OVER (PARTITION BY connectionDeviceId ORDER BY timestamp DESC) as rn
             FROM CashStatusLogs) c ON a.ATMId = c.connectionDeviceId AND c.rn = 1
        LEFT JOIN
            (SELECT
                connectionDeviceId,
                temperature_kvalue,
                temperature_cvalue,
                timestamp,
                ROW_NUMBER() OVER (PARTITION BY connectionDeviceId ORDER BY timestamp DESC) as rn
             FROM TemperatureLogs) t ON a.ATMId = t.connectionDeviceId AND t.rn = 1
        JOIN
            Location l ON a.LocationId = l.LocationId
        WHERE
            l.city = :city
        """, nativeQuery = true)
    List<Object[]> getATMDetailsByCityWithStatus(@Param("city") String city);
    

    // boolean existsByAtmId(String atmId);
}
