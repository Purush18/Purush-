package com.atmmonitor.v3.service;

//import java.text.DecimalFormat;
//import java.time.LocalDateTime;
import java.util.List;
//import java.util.Optional;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

//import com.atmmonitor.v3.dto.TemperatureDto;
import com.atmmonitor.v3.model.TemperatureLogs;
import com.atmmonitor.v3.repository.TemperatureLogsRepository;


@Service
@Transactional
public class TemperatureLogsService {

    private final TemperatureLogsRepository temperatureLogsRepository;
    
    //private final DecimalFormat decimalFormat = new DecimalFormat("0.0");

    public TemperatureLogsService(TemperatureLogsRepository temperatureLogsRepository) {
        this.temperatureLogsRepository = temperatureLogsRepository;
    }
 
    // public List<TemperatureLogs> getAllTemperatureLogs() {
    //     return temperatureLogsRepository.getAllTemperatureLogs();
    // }

  
    // public Optional<TemperatureLogs> getTemperatureLogsById(Integer id) {
    //     return temperatureLogsRepository.findById(id);
    // }

  
    // public TemperatureLogs saveTemperatureLogs(TemperatureLogs temperatureLog) {
    //     return temperatureLogsRepository.save(temperatureLog);
    // }
    
   
    // public TemperatureLogs processIoTTemperatureData(TemperatureDto temperatureDto) {
   
    //     TemperatureLogs temperatureLog = new TemperatureLogs();
    //     temperatureLog.setConnectionDeviceId(temperatureDto.getConnectionDeviceId());
    //     //temperatureLog.setStatus(temperatureDto.getStatus());
        
    //     float roundedKelvin = Math.round(temperatureDto.getTemperature_kvalue() * 100.0f) / 100.0f;
    //     temperatureLog.setTemperatureKvalue(roundedKelvin);
        
    //     float celsiusValue = roundedKelvin - 273.15f;
        
    //     Float formattedCelsius = Float.parseFloat(decimalFormat.format(celsiusValue));
    //     temperatureLog.setTemperatureCvalue(formattedCelsius);
        
    //     temperatureLog.setTimestamp(LocalDateTime.now());
        
    //     return temperatureLogsRepository.save(temperatureLog);
    // }

    // public void deleteTemperatureLogs(Integer id) {
    //     temperatureLogsRepository.deleteById(id);
    // }

    /**
     * Working
     */
    public List<TemperatureLogs> getTemperatureLogsByDeviceId(String deviceId) {
        return temperatureLogsRepository.findByConnectionDeviceId(deviceId);
    }

    /**
     * Get temperature logs by status.
     
    public List<TemperatureLogs> getTemperatureLogsByStatus(String status) {
        return temperatureLogsRepository.findByStatus(status);
    }
    */
   
    // public List<TemperatureLogs> getTemperatureLogsAboveThreshold(Float threshold) {
    //     return temperatureLogsRepository.findByTemperatureKvalueGreaterThan(threshold);
    // }

  
    // public List<TemperatureLogs> getLatestTemperatureByDevice() {
    //     return temperatureLogsRepository.findLatestTemperatureLogsByDevice();
    // }

  
    // public List<TemperatureLogs> getTemperatureLogsByTimePeriod(LocalDateTime startTime, LocalDateTime endTime) {
    //     return temperatureLogsRepository.findByTimestampBetween(startTime, endTime);
    // }

 
    // public Float getAverageTemperatureByDevice(String deviceId, LocalDateTime startTime, LocalDateTime endTime) {
    //     return temperatureLogsRepository.findAverageTemperatureByDevice(deviceId, startTime, endTime);
    // }

   
    // public List<TemperatureLogs> getDevicesWithHighTemperature(Float threshold) {
    //     return temperatureLogsRepository.findDevicesWithHighTemperature(threshold);
    // }

   
    // public List<TemperatureLogs> getDevicesWithLowTemperature(Float threshold) {
    //     return temperatureLogsRepository.findDevicesWithLowTemperature(threshold);
    // }

   
    // @SuppressWarnings("unused")
    // private float convertKelvinToCelsius(float kelvin) {
    //     return kelvin - 273.15f;
    // }
    
   
    // @SuppressWarnings("unused")
    // private float convertCelsiusToKelvin(float celsius) {
    //     return celsius + 273.15f;
    // }
}