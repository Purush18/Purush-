// package com.atmmonitor.v3.dto;

// /**
//  * Data Transfer Object for handling IoT temperature data.
//  */
// public class TemperatureDto {
//     private String connectionDeviceId;
//     private String type;
//     private String status;
//     private Float temperature_kvalue;

//     // Default constructor
//     public TemperatureDto() {
//     }

//     // Getters and setters
//     public String getConnectionDeviceId() {
//         return connectionDeviceId;
//     }

//     public void setConnectionDeviceId(String connectionDeviceId) {
//         this.connectionDeviceId = connectionDeviceId;
//     }

//     public String getType() {
//         return type;
//     }

//     public void setType(String type) {
//         this.type = type;
//     }

//     public String getStatus() {
//         return status;
//     }

//     public void setStatus(String status) {
//         this.status = status;
//     }

//     public Float getTemperature_kvalue() {
//         return temperature_kvalue;
//     }

//     public void setTemperature_kvalue(Float temperature_kvalue) {
//         this.temperature_kvalue = temperature_kvalue;
//     }
// }