// package com.atmmonitor.v3.dto;

// /**
//  * Data Transfer Object for handling IoT cash status data.
//  */
// public class CashStatusDto {
//     private String connectionDeviceId;
//     private String type = "cash";
//     //private String status;
//     private Integer notes100;
//     private Integer notes200;
//     private Integer notes500;

//     // Default constructor
//     public CashStatusDto() {
//     }

//     // Getters and setters
//     public String getConnectionDeviceId() {
//         return connectionDeviceId;
//     }

//     public void setConnectionDeviceId(String connectionDeviceId) {
//         this.connectionDeviceId = connectionDeviceId;
//     }

//     public String getType() {
//         return type;
//     }

//     public void setType(String type) {
//         this.type = type;
//     }
// /* 
//     public String getStatus() {
//         return status;
//     }

//     public void setStatus(String status) {
//         this.status = status;
//     }
// */
//     public Integer getNotes100() {
//         return notes100;
//     }

//     public void setNotes100(Integer notes100) {
//         this.notes100 = notes100;
//     }

//     public Integer getNotes200() {
//         return notes200;
//     }

//     public void setNotes200(Integer notes200) {
//         this.notes200 = notes200;
//     }

//     public Integer getNotes500() {
//         return notes500;
//     }

//     public void setNotes500(Integer notes500) {
//         this.notes500 = notes500;
//     }
// }