package com.atmmonitor.v3.service;

import org.springframework.stereotype.Service;

import com.atmmonitor.v3.model.ATMDetails;
import com.atmmonitor.v3.repository.ATMDetailsRepository;
import com.atmmonitor.v3.repository.LocationRepository;

import java.math.BigDecimal;
import java.util.*;

@Service
public class ATMDetailsService {

    private final ATMDetailsRepository atmDetailsRepository;
    private final LocationRepository locationRepository;
    
    // Default thresholds if not specified in database
    private static final double DEFAULT_TEMP_CELSIUS_THRESHOLD = 30.0;
    private static final BigDecimal DEFAULT_CASH_THRESHOLD = new BigDecimal("50000.00");
    
    public ATMDetailsService(ATMDetailsRepository atmDetailsRepository,LocationRepository locationRepository) {
        this.atmDetailsRepository = atmDetailsRepository;
        this.locationRepository = locationRepository;
    }
    
   
    // public List<ATMDetails> getAllATMDetails() {
    //     return atmDetailsRepository.findAll();
    // }
    
    /**
     * Working
     */
    public Optional<ATMDetails> getATMDetailsById(String atmId) {
        return atmDetailsRepository.findByAtmId(atmId);
    }
    
    /**
     * working
     */
    public Map<String, Object> getATMDetailsWithStatus(String atmId) {
        List<Object[]> results = atmDetailsRepository.getATMDetailsWithStatus(atmId);
        
        if (results.isEmpty()) {
            return null;
        }
        
        return convertATMDetailsToMap(results.get(0));
    }
    
    // Working
    public List<Map<String, Object>> getAllATMDetailsWithStatus() {
        List<Object[]> results = atmDetailsRepository.getAllATMDetailsWithStatus();
        List<Map<String, Object>> detailsList = new ArrayList<>();
        
        for (Object[] result : results) {
            detailsList.add(convertATMDetailsToMap(result));
        }
        
        return detailsList;
    }
    
   
    // public List<String> getAllATMIds() {
    //     return atmDetailsRepository.findAllAtmIds();
    // }
    
   
    // public List<String> getActiveATMIds() {
    //     return atmDetailsRepository.findActiveAtmIds();
    // }
    
   
    private Map<String, Object> convertATMDetailsToMap(Object[] result) {
        Map<String, Object> details = new HashMap<>();
        
        details.put("atmId", result[0]);
        details.put("atmName", result[1]);
        details.put("locationId", result[2]);
        details.put("status", result[3]);
        details.put("totalAmount", result[4]);
        details.put("notes100", result[5]);
        details.put("notes200", result[6]);
        details.put("notes500", result[7]);
        details.put("cashStatus", result[8]); // This will be NULL now, might want to derive a value
        details.put("temperature_kvalue", result[9]);
        details.put("temperature_cvalue", result[10]);
        details.put("tempStatus", result[11]); // This will be NULL now, might want to derive a value
        details.put("lastUpdated", result[12]);
        details.put("temp_c_threshold", result[13]);
        details.put("cash_total_threshold", result[14]);
        details.put("Address", result[15]);
        details.put("State", result[16]);
        
        Float tempThresholdC = (result[13] != null) ? ((Number) result[13]).floatValue() : (float) DEFAULT_TEMP_CELSIUS_THRESHOLD;
        
        BigDecimal cashThreshold;
        if (result[14] != null) {
            if (result[14] instanceof BigDecimal) {
                cashThreshold = (BigDecimal) result[14];
            } else {
                cashThreshold = new BigDecimal(result[14].toString());
            }
        } else {
            cashThreshold = DEFAULT_CASH_THRESHOLD;
        }
        
        boolean lowCash = false;
        if (result[4] != null) {
            BigDecimal amount = (BigDecimal) result[4];
            lowCash = amount.compareTo(cashThreshold) < 0;
        }
        details.put("lowCash", lowCash);
        
        boolean tempAlert = false;
        if (result[9] != null) {
            Double tempK = ((Number) result[9]).doubleValue();
            // Convert kelvin threshold to celsius for comparison
            Double tempThresholdK = tempThresholdC + 273.15;
            tempAlert = tempK > tempThresholdK || tempK < 273.15; // Above threshold or below 0°C
        }
        details.put("temperatureAlert", tempAlert);
        
        if (result[4] != null) {
            details.put("cashStatus", lowCash ? "Low" : "Normal");
        } else {
            details.put("cashStatus", "Unknown");
        }
        
        if (result[9] != null) {
            details.put("tempStatus", tempAlert ? "Alert" : "Normal");
        } else {
            details.put("tempStatus", "Unknown");
        }
        
        return details;
    }

    /* Working */
    public List<String> getAllCities() {
        return locationRepository.findAllDistinctCities();
    }

    // public List<ATMDetails> getATMsByCity(String city) {
    //     return atmDetailsRepository.findATMsByCity(city);
    // }

    // public List<ATMDetails> getATMsByLocationId(String locationId) {
    //     return atmDetailsRepository.findATMsByLocationId(locationId);
    // }

    /* Working */
    public List<Map<String, Object>> getATMDetailsByCityWithStatus(String city) {
        List<Object[]> results = atmDetailsRepository.getATMDetailsByCityWithStatus(city);
        List<Map<String, Object>> detailsList = new ArrayList<>();
        for (Object[] result : results) {
            detailsList.add(convertATMDetailsToMap(result));
        }
        return detailsList;
    }
}
