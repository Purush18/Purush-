package com.atmmonitor.v3.controller;

import java.util.List;
//import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
// import org.springframework.web.bind.annotation.PostMapping;
// import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

//import com.atmmonitor.v3.dto.TemperatureDto;
import com.atmmonitor.v3.model.TemperatureLogs;
import com.atmmonitor.v3.service.IoTHubService;
import com.atmmonitor.v3.service.TemperatureLogsService;


@RestController
@RequestMapping("/api/temperature")
public class TemperatureLogsController {

    private final TemperatureLogsService temperatureLogsService;
    //private final IoTHubService ioTHubService;

    public TemperatureLogsController(TemperatureLogsService temperatureLogsService, IoTHubService ioTHubService) {
        this.temperatureLogsService = temperatureLogsService;
        //this.ioTHubService = ioTHubService;
    }

    
    // @GetMapping
    // public ResponseEntity<List<TemperatureLogs>> getAllTemperatureLogs() {
    //     List<TemperatureLogs> temperatureLogs = temperatureLogsService.getAllTemperatureLogs();
    //     return new ResponseEntity<>(temperatureLogs, HttpStatus.OK);
    // }

    
    // @PostMapping("/iot-data")
    // public ResponseEntity<?> processIoTData(@RequestBody TemperatureDto temperatureDto) {
    //     // Validate if this is a temperature type message
    //     if (!"temperature".equalsIgnoreCase(temperatureDto.getType())) {
    //         return new ResponseEntity<>("Invalid data type. Must be 'temperature'.", HttpStatus.BAD_REQUEST);
    //     }
        
    //     try {
    //         // Send data to IoT Hub
    //         String iotHubStatus = ioTHubService.sendTemperatureData(
    //             temperatureDto.getConnectionDeviceId(),
    //             temperatureDto.getTemperature_kvalue().floatValue()
    //             // The status parameter should be removed from the method call
    //         );
            
    //         return new ResponseEntity<>("Data sent to IoT Hub successfully. Status: " + iotHubStatus, HttpStatus.OK);
    //     } catch (IllegalArgumentException e) {
    //         return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
    //     } catch (Exception e) {
    //         e.printStackTrace();
    //         return new ResponseEntity<>("Error sending data to IoT Hub: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
    //     }
    // }

    
    // @GetMapping("/{id}")
    // public ResponseEntity<TemperatureLogs> getTemperatureLogById(@PathVariable Integer id) {
    //     Optional<TemperatureLogs> temperatureLog = temperatureLogsService.getTemperatureLogsById(id);
    //     return temperatureLog.map(value -> new ResponseEntity<>(value, HttpStatus.OK))
    //             .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    // }

    /* Working */
    @GetMapping("/device/{connectionDeviceId}")
    public ResponseEntity<List<TemperatureLogs>> getTemperatureLogsByDeviceId(@PathVariable String connectionDeviceId) {
        List<TemperatureLogs> temperatureLogs = temperatureLogsService.getTemperatureLogsByDeviceId(connectionDeviceId);
        return new ResponseEntity<>(temperatureLogs, HttpStatus.OK);
    }
  
    // @GetMapping("/latest")
    // public ResponseEntity<List<TemperatureLogs>> getLatestTemperatureByDevice() {
    //     List<TemperatureLogs> latestLogs = temperatureLogsService.getLatestTemperatureByDevice();
    //     return new ResponseEntity<>(latestLogs, HttpStatus.OK);
    // }

   
    // @GetMapping("/high-temperature")
    // public ResponseEntity<List<TemperatureLogs>> getDevicesWithHighTemperature(
    //         @RequestParam(defaultValue = "303.15") Float threshold) {
    //     List<TemperatureLogs> highTempDevices = temperatureLogsService.getDevicesWithHighTemperature(threshold);
    //     return new ResponseEntity<>(highTempDevices, HttpStatus.OK);
    // }

   
    // @GetMapping("/low-temperature")
    // public ResponseEntity<List<TemperatureLogs>> getDevicesWithLowTemperature(
    //         @RequestParam(defaultValue = "283.15") Float threshold) {
    //     List<TemperatureLogs> lowTempDevices = temperatureLogsService.getDevicesWithLowTemperature(threshold);
    //     return new ResponseEntity<>(lowTempDevices, HttpStatus.OK);
    // }
}