package com.atmmonitor.v3.model;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import com.fasterxml.jackson.annotation.JsonFormat;


@Entity
@Table(name = "TemperatureLogs")
public class TemperatureLogs {
    
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "temlogid")
    private Integer temlogid;
    
    
    @NotNull
    @Column(name = "connectionDeviceId", length = 50, nullable = false)
    private String connectionDeviceId;
    
    
    @NotNull
    @Column(name = "timestamp", nullable = false)
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS")
    private LocalDateTime timestamp;
    
 
    @NotNull
    @Column(name = "temperature_kvalue", nullable = false)
    private Float temperatureKvalue;
    
  
    @NotNull
    @Column(name = "temperature_cvalue", length = 10, nullable = false)
    private Float temperatureCvalue;
    
    
    public TemperatureLogs() {
    }
    
  
    public TemperatureLogs(String connectionDeviceId, LocalDateTime timestamp, Float temperatureKvalue, 
    Float temperatureCvalue) {
        this.connectionDeviceId = connectionDeviceId;
        this.timestamp = timestamp;
        this.temperatureKvalue = temperatureKvalue;
        this.temperatureCvalue = temperatureCvalue;
        //this.status = status;
    }

    // Getters and Setters
    
    public Integer getTemlogid() {
        return temlogid;
    }

    public void setTemlogid(Integer temlogid) {
        this.temlogid = temlogid;
    }

    public String getConnectionDeviceId() {
        return connectionDeviceId;
    }

    public void setConnectionDeviceId(String connectionDeviceId) {
        this.connectionDeviceId = connectionDeviceId;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }

    public Float getTemperatureKvalue() {
        return temperatureKvalue;
    }

    public void setTemperatureKvalue(Float temperatureKvalue) {
        this.temperatureKvalue = temperatureKvalue;
    }

    public Float getTemperatureCvalue() {
        return temperatureCvalue;
    }

    public void setTemperatureCvalue(Float temperatureCvalue) {
        this.temperatureCvalue = temperatureCvalue;
    }

    @Override
    public String toString() {
        return "TemperatureLogs{" +
                "temlogid=" + temlogid +
                ", connectionDeviceId='" + connectionDeviceId + '\'' +
                ", timestamp=" + timestamp +
                ", temperatureKvalue=" + temperatureKvalue +
                ", temperatureCvalue='" + temperatureCvalue + '\'' +
                //", status='" + status + '\'' +
                '}';
    }
}