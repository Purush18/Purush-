package com.atmmonitor.v3.model;

import java.time.OffsetDateTime;

public class ServiceBusMessage {
    private String messageId;
    private String body;
    private OffsetDateTime enqueuedTime;
    
    // Constructors
    public ServiceBusMessage() {}
    
    public ServiceBusMessage(String messageId, String body, OffsetDateTime enqueuedTime) {
        this.messageId = messageId;
        this.body = body;
        this.enqueuedTime = enqueuedTime;
    }
    
    // Getters and Setters
    public String getMessageId() {
        return messageId;
    }
    
    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }
    
    public String getBody() {
        return body;
    }
    
    public void setBody(String body) {
        this.body = body;
    }
    
    public OffsetDateTime getEnqueuedTime() {
        return enqueuedTime;
    }
    
    public void setEnqueuedTime(OffsetDateTime enqueuedTime) {
        this.enqueuedTime = enqueuedTime;
    }
}
