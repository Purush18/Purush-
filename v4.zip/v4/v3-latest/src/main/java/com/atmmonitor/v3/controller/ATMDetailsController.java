package com.atmmonitor.v3.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

//import com.atmmonitor.v3.dto.TemperatureDto;
//import com.atmmonitor.v3.model.ATMDetails;
import com.atmmonitor.v3.service.ATMDetailsService;
import com.atmmonitor.v3.service.CashStatusLogsService;
import com.atmmonitor.v3.service.IoTHubService;
import com.atmmonitor.v3.service.TemperatureLogsService;
import com.atmmonitor.v3.dto.MessageDto;

import java.util.List;
import java.util.Map;
import java.util.HashMap;

@RestController
@RequestMapping("/api/atm-details")
@CrossOrigin(origins = {"http://localhost:8080", "http://127.0.0.1:8080"})
public class ATMDetailsController {

    private final ATMDetailsService atmDetailsService;
    private final IoTHubService ioTHubService;
    //private final TemperatureLogsService temperatureLogsService;
    //private final CashStatusLogsService cashStatusLogsService;
    
    public ATMDetailsController(ATMDetailsService atmDetailsService, 
                               IoTHubService ioTHubService,
                               TemperatureLogsService temperatureLogsService,
                               CashStatusLogsService cashStatusLogsService) {
        this.atmDetailsService = atmDetailsService;
        this.ioTHubService = ioTHubService;
        //this.temperatureLogsService = temperatureLogsService;
        //this.cashStatusLogsService = cashStatusLogsService;
    }
    
    // @GetMapping
    // public ResponseEntity<List<ATMDetails>> getAllATMDetails() {
    //     List<ATMDetails> details = atmDetailsService.getAllATMDetails();
    //     return ResponseEntity.ok(details);
    // }
    
    // @GetMapping("/{atmId}")
    // public ResponseEntity<?> getATMDetailsById(@PathVariable String atmId) {
    //     return atmDetailsService.getATMDetailsById(atmId)
    //             .map(ResponseEntity::ok)
    //             .orElse(ResponseEntity.notFound().build());
    // }
    
    /**
     * Working
     */
    @GetMapping("/{atmId}/status")
    public ResponseEntity<?> getATMDetailsWithStatus(@PathVariable String atmId) {
        Map<String, Object> details = atmDetailsService.getATMDetailsWithStatus(atmId);
        
        if (details == null) {
            return ResponseEntity.notFound().build();
        }
        
        return ResponseEntity.ok(details);
    }
    
    /**
     * Working
     */
    @GetMapping("/all/status")
    public ResponseEntity<List<Map<String, Object>>> getAllATMDetailsWithStatus() {
        System.out.println("API call received: /api/atm-details/all/status"); // Debugging
        try {
            List<Map<String, Object>> allDetails = atmDetailsService.getAllATMDetailsWithStatus();
            System.out.println("Returning " + allDetails.size() + " ATM details"); // Debugging
            return ResponseEntity.ok(allDetails);
        } catch (Exception e) {
            System.err.println("Error in getAllATMDetailsWithStatus: " + e.getMessage()); // Debugging
            e.printStackTrace();
            throw e;
        }
    }
    
   
    // @GetMapping("/ids")
    // public ResponseEntity<List<String>> getAllATMIds() {
    //     List<String> ids = atmDetailsService.getAllATMIds();
    //     return ResponseEntity.ok(ids);
    // }
    
    
    // @GetMapping("/ids/active")
    // public ResponseEntity<List<String>> getActiveATMIds() {
    //     List<String> activeIds = atmDetailsService.getActiveATMIds();
    //     return ResponseEntity.ok(activeIds);
    // }

    /* Working */
    @GetMapping("/verify/{atmId}")
    public ResponseEntity<?> verifyATMExists(@PathVariable String atmId) {
        boolean exists = atmDetailsService.getATMDetailsById(atmId).isPresent();
        
        if (exists) {
            // Return minimal data if ATM exists
            Map<String, Object> response = new HashMap<>();
            response.put("exists", true);
            response.put("atmId", atmId);
            return ResponseEntity.ok(response);
        } else {
            // Return 404 if ATM doesn't exist
            return ResponseEntity.notFound().build();
        }
    }

    /* Working */
    @PostMapping("/iot-data")
    public ResponseEntity<?> processIoTData(@RequestBody MessageDto messageDto) {
        try {
            StringBuilder result = new StringBuilder();
            
            if(messageDto.getStatus() != null) {
                String atmResult = ioTHubService.sendAtmStatusData(
                    messageDto.getConnectionDeviceId(),
                    messageDto.getStatus()
                );
                result.append("Atm data processed: ").append(atmResult).append(". ");
            }
            
            if (messageDto.getTemperatureData() != null && 
                messageDto.getTemperatureData().getTemperature_kvalue() != null) {
                
                String tempResult = ioTHubService.sendTemperatureData(
                    messageDto.getConnectionDeviceId(),
                    messageDto.getTemperatureData().getTemperature_kvalue().floatValue()
                );
                
                result.append("Temperature data processed: ").append(tempResult).append(". ");
            }
            
            if (messageDto.getCashData() != null) {
                String cashResult = ioTHubService.sendCashStatusData(
                    messageDto.getConnectionDeviceId(),
                    messageDto.getCashData().getNotes100(),
                    messageDto.getCashData().getNotes200(),
                    messageDto.getCashData().getNotes500()
                );
                
                result.append("Cash data processed: ").append(cashResult);
            }
            
            return ResponseEntity.ok(result.toString());
            
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                               .body("Error processing data: " + e.getMessage());
        }
    }

    /* Working */
    @GetMapping("/cities")
    public ResponseEntity<List<String>> getAllCities() {
        List<String> cities = atmDetailsService.getAllCities();
        return ResponseEntity.ok(cities);
    }

    // @GetMapping("/by-city")
    // public ResponseEntity<List<ATMDetails>> getATMsByCity(@RequestParam String city) {
    //     List<ATMDetails> atms = atmDetailsService.getATMsByCity(city);
    //     return ResponseEntity.ok(atms);
    // }

    // @GetMapping("/by-location")
    // public ResponseEntity<List<ATMDetails>> getATMsByLocationId(@RequestParam String locationId) {
    //     List<ATMDetails> atms = atmDetailsService.getATMsByLocationId(locationId);
    //     return ResponseEntity.ok(atms);
    // }

    /* Working */
    @GetMapping("/by-city/details")
    public ResponseEntity<List<Map<String, Object>>> getATMDetailsByCityWithStatus(@RequestParam String city) {
        try {
            List<Map<String, Object>> atmDetails = atmDetailsService.getATMDetailsByCityWithStatus(city);
            return ResponseEntity.ok(atmDetails);
        } catch (Exception e) {
            System.err.println("Error fetching ATM details for city: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

}
