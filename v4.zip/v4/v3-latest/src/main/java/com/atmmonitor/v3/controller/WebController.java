package com.atmmonitor.v3.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class WebController {

 
    @GetMapping("/admin/dashboard")
    public String adminDashboard() {
        return "redirect:/admin-dashboard.html";
    }

    @GetMapping("/user/dashboard")
    public String userDashboard() {
        return "redirect:/techie-dashboard.html";
    }

    @GetMapping("/user/send-commands")
    public String sendCommands() {
        return "redirect:/send-commands-techie.html";
    }

}
