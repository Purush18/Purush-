package com.atmmonitor.v3.repository;

//import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.data.jpa.repository.Query;
//import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.atmmonitor.v3.model.TemperatureLogs;

@Repository
public interface TemperatureLogsRepository extends JpaRepository<TemperatureLogs, Integer> {
    
//     @Query("SELECT t FROM TemperatureLogs t")
//     List<TemperatureLogs> getAllTemperatureLogs();
    
//     @Query("SELECT t FROM TemperatureLogs t")
//     List<TemperatureLogs> saveAllTemperatureLogs();

//     @Query(value = "INSERT INTO TemperatureLogs (connection_device_id, timestamp, temperature_kvalue, temperature_cvalue) " +
//            "VALUES (:#{#log.connectionDeviceId}, :#{#log.timestamp}, :#{#log.temperatureKvalue}, :#{#log.temperatureCvalue})", 
//            nativeQuery = true)
//     TemperatureLogs insertTemperatureLog(@Param("log") TemperatureLogs log);

       // Working
       List<TemperatureLogs> findByConnectionDeviceId(String connectionDeviceId);
       
//     List<TemperatureLogs> findByTemperatureKvalueGreaterThan(Float threshold);
    
   
//     List<TemperatureLogs> findByTimestampBetween(LocalDateTime startTime, LocalDateTime endTime);
    
   
//     @Query("SELECT t FROM TemperatureLogs t WHERE t.timestamp = " +
//            "(SELECT MAX(t2.timestamp) FROM TemperatureLogs t2 WHERE t2.connectionDeviceId = t.connectionDeviceId)")
//     List<TemperatureLogs> findLatestTemperatureLogsByDevice();
    
   
//     @Query("SELECT AVG(t.temperatureKvalue) FROM TemperatureLogs t " +
//            "WHERE t.connectionDeviceId = :connectionDeviceId AND t.timestamp BETWEEN :startTime AND :endTime")
//     Float findAverageTemperatureByDevice(
//         @Param("connectionDeviceId") String connectionDeviceId, 
//         @Param("startTime") LocalDateTime startTime, 
//         @Param("endTime") LocalDateTime endTime
//     );
    
//     @Query("SELECT t FROM TemperatureLogs t WHERE t.timestamp = " +
//            "(SELECT MAX(t2.timestamp) FROM TemperatureLogs t2 WHERE t2.connectionDeviceId = t.connectionDeviceId) " +
//            "AND t.temperatureKvalue > :threshold")
//     List<TemperatureLogs> findDevicesWithHighTemperature(@Param("threshold") Float threshold);
    

//     @Query("SELECT t FROM TemperatureLogs t WHERE t.timestamp = " +
//            "(SELECT MAX(t2.timestamp) FROM TemperatureLogs t2 WHERE t2.connectionDeviceId = t.connectionDeviceId) " +
//            "AND t.temperatureKvalue < :threshold")
//     List<TemperatureLogs> findDevicesWithLowTemperature(@Param("threshold") Float threshold);
}