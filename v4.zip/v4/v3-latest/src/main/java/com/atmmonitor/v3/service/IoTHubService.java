package com.atmmonitor.v3.service;

import com.microsoft.azure.sdk.iot.device.*;
import com.microsoft.azure.sdk.iot.device.exceptions.IotHubClientException;
import org.springframework.stereotype.Service;
import com.google.gson.Gson;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
//import java.util.Arrays;
//import java.util.List;


@Service
public class IoTHubService {

    private static final Logger logger = LoggerFactory.getLogger(IoTHubService.class);

    // The device connection string to authenticate the device with your IoT hub.
    //private static final String CONN_STRING_TEMP = "HostName=atm-monitor-iothub-az.azure-devices.net;DeviceId=temperature-monitor;SharedAccessKey=mdk2hzzHEZi4Jo+KAm8qoLbBG1k+h+NrrgFryQ4dQlA=";
    //private static final String CONN_STRING_CASH = "HostName=atm-monitor-iothub-az.azure-devices.net;DeviceId=temperature-monitor;SharedAccessKey=mdk2hzzHEZi4Jo+KAm8qoLbBG1k+h+NrrgFryQ4dQlA=";
    //private static final String CONN_STRING_CASH = "HostName=atm-monitor-iothub-az.azure-devices.net;DeviceId=cashFlow-monitor;SharedAccessKey=RPxfGyE+hdXBYGD/NEc6SXwXEwGhsCD6aoYDFpyTemo=";

    //private static final String CONN_STRING_TEMP = "HostName=atm-monitor-iothub-az.azure-devices.net;DeviceId=temperature-monitor;SharedAccessKey=7A/xIsocD0y+O/2/LAAuSTL01Gmw1fwOy1sijs72570=";
    //private static final String CONN_STRING_CASH = "HostName=atm-monitor-iothub-az.azure-devices.net;DeviceId=temperature-monitor;SharedAccessKey=mdk2hzzHEZi4Jo+KAm8qoLbBG1k+h+NrrgFryQ4dQlA=";
    //private static final String CONN_STRING_CASH = "HostName=atm-monitor-iothub-az.azure-devices.net;DeviceId=cashFlow-monitor;SharedAccessKey=y88EZrnttrXb2nHPxft55chBTisZbpqm1EIWlO0nNGA=";
    private static final String CONN_STRING_TEMP = "HostName=atm-monitor-iothub-azure.azure-devices.net;DeviceId=temperature-monitor;SharedAccessKey=cAhFA0EBjHl7xZtjGREVKBJlXlb/4So+knV31R1sXeQ=";  
    private static final String CONN_STRING_CASH = "HostName=atm-monitor-iothub-azure.azure-devices.net;DeviceId=cashFlow-monitor;SharedAccessKey=f76lA6j0mLVy95EIm6rnXTagcaspPTIcd/qYvKm7Z6Q=";    
    private static final IotHubClientProtocol PROTOCOL = IotHubClientProtocol.MQTT;

    // private static final List<String> VALID_STATUSES = Arrays.asList("online", "maintenance", "offline");

    public static abstract class BaseDataPoint {
        public String connectionDeviceId;
        public String timestamp;
        public String status;
        public String type;
      
        public abstract String serialize();
    }

    public static class TemperatureDataPoint extends BaseDataPoint {
        public double temperature_kvalue;
        public double temperature_cvalue;

        @Override
        public String serialize() {
            Gson gson = new Gson();
            return gson.toJson(this);
        }
    }

    public static class CashStatusDataPoint extends BaseDataPoint {
        public long notes100;
        public long notes200;
        public long notes500;
        public double totalamount;
        
        @Override
        public String serialize() {
            Gson gson = new Gson();
            return gson.toJson(this);
        }
    
        public void calculateTotalAmount() {
            this.totalamount = (notes100 * 100.0) + (notes200 * 200.0) + (notes500 * 500.0);
            this.totalamount = Math.round(this.totalamount * 100.0) / 100.0;
        }
    }

    public static class AtmStatusDataPoint extends BaseDataPoint {
        @Override
        public String serialize() {
            Gson gson = new Gson();
            return gson.toJson(this);
        }
    }

    private static class EventCallback implements MessageSentCallback {
        private String status;

        @Override
        public void onMessageSent(Message sentMessage, IotHubClientException exception, Object callbackContext) {
            status = (exception == null ? IotHubStatusCode.OK.toString() : exception.getStatusCode().toString());
            System.out.println("IoT Hub responded to message with status: " + status);
            if (callbackContext != null) {
                synchronized (callbackContext) {
                    callbackContext.notify();
                }
            }
        }

        public String getStatus() {
            return status;
        }
    }

   // Working
    public String sendTemperatureData(String deviceId, Float temperatureKvalue) throws Exception {
        if (deviceId == null || deviceId.trim().isEmpty()) {
            throw new IllegalArgumentException("Device ID cannot be null or empty");
        }
        
        if (temperatureKvalue == null) {
            throw new IllegalArgumentException("Temperature value cannot be null");
        }
        
        TemperatureDataPoint dataPoint = new TemperatureDataPoint();
        dataPoint.connectionDeviceId = deviceId;
        dataPoint.temperature_kvalue = temperatureKvalue;
        
        dataPoint.temperature_cvalue = Math.round((temperatureKvalue - 273.15) * 100.0) / 100.0;
        
        //dataPoint.status = "online";

        dataPoint.timestamp = OffsetDateTime.now().format(DateTimeFormatter.ISO_OFFSET_DATE_TIME);
        dataPoint.type = "temperature";

        return sendDataPointToIoT(dataPoint, CONN_STRING_TEMP);
    }

    // Working
    public String sendCashStatusData(String deviceId, Integer notes100, Integer notes200, Integer notes500) throws Exception {
        if (deviceId == null || deviceId.trim().isEmpty()) {
            throw new IllegalArgumentException("Device ID cannot be null or empty");
        }
        
        if (notes100 == null) notes100 = 0;
        if (notes200 == null) notes200 = 0;
        if (notes500 == null) notes500 = 0;
        
        // Create cash status data point
        CashStatusDataPoint dataPoint = new CashStatusDataPoint();
        dataPoint.connectionDeviceId = deviceId;
        dataPoint.notes100 = notes100;
        dataPoint.notes200 = notes200;
        dataPoint.notes500 = notes500;
        
        // dataPoint.status = "online";
        
        dataPoint.calculateTotalAmount();
        
        dataPoint.timestamp = OffsetDateTime.now().format(DateTimeFormatter.ISO_OFFSET_DATE_TIME);
        dataPoint.type = "cash";
        
        return sendDataPointToIoT(dataPoint, CONN_STRING_CASH);
    }

    // Working
    public String sendAtmStatusData(String deviceId, String status) throws Exception {
        // Add debug logging at start
        logger.debug("Attempting to send ATM status - Device ID: {}, Status: {}", deviceId, status);
        
        if (deviceId == null || deviceId.trim().isEmpty()) {
            logger.error("Device ID cannot be null or empty");
            throw new IllegalArgumentException("Device ID cannot be null or empty");
        }
        
        if (status == null || status.trim().isEmpty()) {
            logger.error("Status cannot be null or empty");
            throw new IllegalArgumentException("Status cannot be null or empty");
        }
        
        AtmStatusDataPoint dataPoint = new AtmStatusDataPoint();
        dataPoint.connectionDeviceId = deviceId;
        dataPoint.status = status;
        dataPoint.timestamp = OffsetDateTime.now().format(DateTimeFormatter.ISO_OFFSET_DATE_TIME);
        dataPoint.type = "atmdata";
        
        logger.info("Sending ATM status message: {}", dataPoint.serialize());
        
        String result = sendDataPointToIoT(dataPoint, CONN_STRING_CASH);
        logger.info("ATM status message result: {}", result);
        return result;
    }
    
   
    private String sendDataPointToIoT(BaseDataPoint dataPoint, String CONN_STRING) throws Exception {
        DeviceClient client = null;
        try {
            client = new DeviceClient(CONN_STRING, PROTOCOL);
            
            System.out.println("Connecting to IoT Hub with connection string: " + 
                CONN_STRING.substring(0, 20) + "...[truncated]");
                
            client.open(true);
            System.out.println("Connected to IoT Hub successfully");
            
            String msgStr = dataPoint.serialize();
            Message msg = new Message(msgStr);
            
            msg.setContentEncoding("utf-8");
            msg.setContentType("application/json");
            msg.setProperty("type", dataPoint.type);
            
            System.out.println("Sending message: " + msgStr);

            Object lockobj = new Object();
            EventCallback callback = new EventCallback();

            client.sendEventAsync(msg, callback, lockobj);

            synchronized (lockobj) {
                lockobj.wait(5000);  // Wait up to 5 seconds for response
            }

            String responseStatus = callback.getStatus();
            if (responseStatus == null) {
                throw new Exception("Timeout waiting for IoT Hub response");
            }
            
            System.out.println("IoT Hub response: " + responseStatus);
            return responseStatus;
            
        } catch (Exception e) {
            System.err.println("Error sending data to IoT Hub: " + e.getMessage());
            e.printStackTrace();
            throw e;
        } finally {
            if (client != null) {
                try {
                    client.close();
                    System.out.println("IoT Hub client closed");
                } catch (Exception e) {
                    System.err.println("Error closing IoT Hub client: " + e.getMessage());
                }
            }
        }
    }
}
