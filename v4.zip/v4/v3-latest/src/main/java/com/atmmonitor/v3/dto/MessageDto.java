package com.atmmonitor.v3.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Data Transfer Object for ATM message requests.
 */
public class MessageDto {
    private String connectionDeviceId;
    private String status;
    
    @JsonProperty("temp-data")
    private TemperatureData temperatureData;
    
    @JsonProperty("cash-data")
    private CashData cashData;
    

    // Nested class for temperature data
    public static class TemperatureData {
        private Double temperature_kvalue;
        
        public Double getTemperature_kvalue() {
            return temperature_kvalue;
        }
        
        public void setTemperature_kvalue(Double temperature_kvalue) {
            this.temperature_kvalue = temperature_kvalue;
        }
    }
    
    // Nested class for cash data
    public static class CashData {
        private Integer notes100;
        private Integer notes200;
        private Integer notes500;
        
        public Integer getNotes100() {
            return notes100;
        }
        
        public void setNotes100(Integer notes100) {
            this.notes100 = notes100;
        }
        
        public Integer getNotes200() {
            return notes200;
        }
        
        public void setNotes200(Integer notes200) {
            this.notes200 = notes200;
        }
        
        public Integer getNotes500() {
            return notes500;
        }
        
        public void setNotes500(Integer notes500) {
            this.notes500 = notes500;
        }
    }
    
    // Getters and setters for main class
    public String getConnectionDeviceId() {
        return connectionDeviceId;
    }
    
    public void setConnectionDeviceId(String connectionDeviceId) {
        this.connectionDeviceId = connectionDeviceId;
    }
    
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    public TemperatureData getTemperatureData() {
        return temperatureData;
    }
    
    public void setTemperatureData(TemperatureData temperatureData) {
        this.temperatureData = temperatureData;
    }
    
    public CashData getCashData() {
        return cashData;
    }
    
    public void setCashData(CashData cashData) {
        this.cashData = cashData;
    }
}