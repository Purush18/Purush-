package com.atmmonitor.v3.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.atmmonitor.v3.model.Location;
import java.util.List;
@Repository
public interface LocationRepository extends JpaRepository<Location, String> {
    
    // Working
    @Query("SELECT DISTINCT l.city FROM Location l WHERE l.city IS NOT NULL")
    List<String> findAllDistinctCities();


    @Query("SELECT l FROM Location l WHERE l.city = :city")
    List<Location> findLocationsByCity(String city);
}
