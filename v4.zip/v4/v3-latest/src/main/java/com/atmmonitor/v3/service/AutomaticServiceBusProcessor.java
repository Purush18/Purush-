package com.atmmonitor.v3.service;

//import com.atmmonitor.v3.model.CashStatusLogs;
import com.atmmonitor.v3.model.TemperatureLogs;
import com.atmmonitor.v3.repository.TemperatureLogsRepository;
import com.atmmonitor.v3.repository.CashStatusLogsRepository;
import com.atmmonitor.v3.repository.ATMDetailsRepository;

import com.azure.messaging.servicebus.ServiceBusClientBuilder;
import com.azure.messaging.servicebus.ServiceBusProcessorClient;
import com.azure.messaging.servicebus.ServiceBusReceivedMessage;
import com.azure.messaging.servicebus.ServiceBusReceivedMessageContext;
import com.azure.messaging.servicebus.ServiceBusErrorContext;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;

//import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.atomic.AtomicInteger;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AutomaticServiceBusProcessor {
    
    private static final Logger logger = LoggerFactory.getLogger(AutomaticServiceBusProcessor.class);
    
    private final ServiceBusClientBuilder clientBuilder;
    private final ObjectMapper objectMapper;
    private ServiceBusProcessorClient processorClient;
    private final TemperatureLogsRepository temperatureLogsRepository;
    //private final CashStatusLogsRepository cashStatusLogsRepository;
    private final ATMDetailsRepository atmDetailsRepository;
    
    // Message processing statistics
    private final AtomicInteger totalMessagesProcessed = new AtomicInteger(0);
    private final AtomicInteger temperatureMessagesProcessed = new AtomicInteger(0);
    private final AtomicInteger cashStatusMessagesProcessed = new AtomicInteger(0);
    private final AtomicInteger unknownMessagesProcessed = new AtomicInteger(0);
    private final AtomicInteger errorCount = new AtomicInteger(0);
    
    @Value("${app.servicebus.listener.enabled:true}")
    private boolean listenerEnabled;
    
    @Value("${azure.servicebus.topic-name}")
    private String topicName;
    
    @Value("${azure.servicebus.subscription-name}")
    private String subscriptionName;
    
    public AutomaticServiceBusProcessor(
            ServiceBusClientBuilder clientBuilder,
            ObjectMapper objectMapper,
            TemperatureLogsRepository temperatureLogsRepository,
            CashStatusLogsRepository cashStatusLogsRepository,
            ATMDetailsRepository atmDetailsRepository) {
        this.clientBuilder = clientBuilder;
        this.objectMapper = objectMapper;
        this.temperatureLogsRepository = temperatureLogsRepository;
        //this.cashStatusLogsRepository = cashStatusLogsRepository;
        this.atmDetailsRepository = atmDetailsRepository;
    }
    
    @Transactional
    public void saveTemperatureMessage(JsonNode jsonNode) {
        try {
            logger.info("welcome to update Temperature");
            TemperatureLogs temperatureLog = new TemperatureLogs();
            
            String deviceId = null;
            if (jsonNode.has("connectionDeviceId")) {
                deviceId = jsonNode.path("connectionDeviceId").asText();
            } else if (jsonNode.has("deviceId")) {
                deviceId = jsonNode.path("deviceId").asText();
            } else if (jsonNode.has("device_id")) {
                deviceId = jsonNode.path("device_id").asText();
            }
            
            if (deviceId == null || deviceId.isEmpty()) {
                deviceId = "unknown-device-" + System.currentTimeMillis();
                logger.warn("No device ID found in message, using generated ID: {}", deviceId);
            }
            
            temperatureLog.setConnectionDeviceId(deviceId);
            
            if (jsonNode.has("timestamp")) {
                String timestampStr = jsonNode.path("timestamp").asText();
                LocalDateTime timestamp = parseTimestamp(timestampStr);
                temperatureLog.setTimestamp(timestamp);
            } else {
                temperatureLog.setTimestamp(LocalDateTime.now());
            }
            
            float temperatureK = 0;
            if (jsonNode.has("temperature_kvalue")) {
                temperatureK = jsonNode.path("temperature_kvalue").floatValue();
            } else if (jsonNode.has("temperature")) {
            
                temperatureK = jsonNode.path("temperature").floatValue() + 273.15f;
            }
            
            
            temperatureK = Math.round(temperatureK * 100) / 100.0f;
            temperatureLog.setTemperatureKvalue(temperatureK);
            
            
            float temperatureC = Math.round((temperatureK - 273.15f) * 100) / 100.0f;
            temperatureLog.setTemperatureCvalue(temperatureC);
            
            //temperatureLog.setStatus(jsonNode.path("status").asText("online")); // Default to 'online' if not present
            
            temperatureLogsRepository.save(temperatureLog);
            logger.info("Saved temperature log for device: {}, K: {}, C: {}", 
                temperatureLog.getConnectionDeviceId(), 
                temperatureLog.getTemperatureKvalue(),
                temperatureLog.getTemperatureCvalue());
        } catch (Exception e) {
            logger.error("Error saving temperature message: {}", e.getMessage(), e);
            //throw new Exception("Failed to save temperature message", e);
        }
    }
    
    /**
    
    public void saveCashStatusMessage(JsonNode jsonNode) {
        try {
            CashStatusLogs cashStatusLog = new CashStatusLogs();
            
            // Extract required fields
            cashStatusLog.setConnectionDeviceId(jsonNode.path("deviceId").asText());
            
            // Handle timestamp
            String timestampStr = jsonNode.path("timestamp").asText();
            LocalDateTime timestamp = parseTimestamp(timestampStr);
            cashStatusLog.setTimestamp(timestamp);
            
            // Handle notes counts
            cashStatusLog.setNotes100(jsonNode.path("notes100").asInt());
            cashStatusLog.setNotes200(jsonNode.path("notes200").asInt());
            cashStatusLog.setNotes500(jsonNode.path("notes500").asInt());
            
            // Set status
           // cashStatusLog.setStatus(jsonNode.path("status").asText("online")); // Default to 'online' if not present
            
            // Calculate total amount or use provided value
            if (jsonNode.has("totalamount")) {
                cashStatusLog.setTotalamount(new BigDecimal(jsonNode.path("totalamount").asText()));
            } else {
                cashStatusLog.calculateTotalAmount(); // Use the model method to calculate
            }
            
            // Save to repository
            cashStatusLogsRepository.save(cashStatusLog);
            logger.info("Saved cash status log for device: {}", cashStatusLog.getConnectionDeviceId());
        } catch (Exception e) {
            logger.error("Error saving cash status message: {}", e.getMessage(), e);
            //throw new ServiceBusOperationException("Failed to save cash status message", e);
        }
    }
     */
   
    @Transactional
    public void updateAtmStatus(JsonNode jsonNode) {
        try {
            logger.info("Welcome to update ATM status");
            String deviceId = jsonNode.path("connectionDeviceId").asText();
            
            if (deviceId == null || deviceId.isEmpty()) {
                logger.warn("No connectionDeviceId found in atmdata message");
                return;
            }
            // Get status directly from the message for simple format
            String status = jsonNode.path("status").asText();
            
            // If status is empty, try nested format
            // if (status.isEmpty() && jsonNode.has("atmdata")) {
            //     status = jsonNode.path("atmdata").path("status").asText();
            // }
            
            if (status.isEmpty()) {
                logger.warn("No status found in atmdata message");
                return;
            }

            logger.info("Attempting to update ATM status: Device={}, Status={}", deviceId, status);
            
            atmDetailsRepository.findByAtmId(deviceId).ifPresentOrElse(
                atmDetails -> {
                    atmDetails.setStatus(status);
                    atmDetailsRepository.save(atmDetails);
                    logger.info("Updated ATM status for ATM ID {}: {}", deviceId, status);
                },
                () -> logger.warn("No ATM found with ATM ID: {}", deviceId)
            );
        } catch (Exception e) {
            logger.error("Error updating ATM status: {}", e.getMessage(), e);
        }
    }
    
    
    private LocalDateTime parseTimestamp(String timestampStr) {
        try {
            return ZonedDateTime.parse(timestampStr).toLocalDateTime();
        } catch (Exception e1) {
            try {
                // Try custom format
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
                return LocalDateTime.parse(timestampStr, formatter);
            } catch (Exception e2) {
                // Fall back to current time if parsing fails
                logger.warn("Could not parse timestamp: {}. Using current time.", timestampStr);
                return LocalDateTime.now();
            }
        }
    }
   
    @PostConstruct
    public void startMessageProcessing() {
        if (!listenerEnabled) {
            logger.info("Automatic Service Bus processor is disabled");
            return;
        }
        
        logger.info("Starting automatic Service Bus message processor...");
        
        try {
            this.processorClient = clientBuilder
                .processor()
                .topicName(topicName)
                .subscriptionName(subscriptionName)
                .processMessage(this::processMessage)
                .processError(this::processError)
                .buildProcessorClient();
            
            this.processorClient.start();
            logger.info("Automatic Service Bus processor started successfully");
        } catch (Exception e) {
            logger.error("Failed to start Service Bus processor: {}", e.getMessage(), e);
        }
    }
    
    private void processMessage(ServiceBusReceivedMessageContext context) {
        ServiceBusReceivedMessage message = context.getMessage();
        
        try {
            String messageBody = message.getBody().toString();
            logger.debug("Processing message: {}", messageBody);
            
            JsonNode jsonNode = objectMapper.readTree(messageBody);
            boolean messageProcessed = false;
            
            if (jsonNode.has("type") && "atmdata".equals(jsonNode.path("type").asText())) {
                updateAtmStatus(jsonNode);
                totalMessagesProcessed.incrementAndGet();
                logger.debug("Processed ATM status message");
                messageProcessed = true;
            }
            
            if (jsonNode.has("temperature_kvalue") || jsonNode.has("temperature")) {
                saveTemperatureMessage(jsonNode);
                temperatureMessagesProcessed.incrementAndGet();
                logger.debug("Processed temperature message");
                messageProcessed = true;
            }
            
            if (!messageProcessed) {
                logger.warn("Received unknown message type: {}", messageBody);
                unknownMessagesProcessed.incrementAndGet();
            }
            
            int total = totalMessagesProcessed.get();
            if (total % 10 == 0) {
                logProcessingStatistics();
            }
            
            context.complete();
            
        } catch (Exception e) {
            logger.error("Error processing Service Bus message: {}", e.getMessage(), e);
            errorCount.incrementAndGet();
            context.abandon();
        }
    }
    
    private void processError(ServiceBusErrorContext errorContext) {
        logger.error("Service Bus processor encountered an error: {}", errorContext.getException().getMessage(), errorContext.getException());
        errorCount.incrementAndGet();
    }
    
    private void logProcessingStatistics() {
        logger.info("Service Bus processing statistics - " +
                "Total: {}, Temperature: {}, Cash Status: {}, Unknown: {}, Errors: {}",
                totalMessagesProcessed.get(),
                temperatureMessagesProcessed.get(),
                cashStatusMessagesProcessed.get(),
                unknownMessagesProcessed.get(),
                errorCount.get());
    }
    
    public ProcessingStatistics getStatistics() {
        return new ProcessingStatistics(
                totalMessagesProcessed.get(),
                temperatureMessagesProcessed.get(),
                cashStatusMessagesProcessed.get(),
                unknownMessagesProcessed.get(),
                errorCount.get(),
                processorClient != null && processorClient.isRunning()
        );
    }
    
    @PreDestroy
    public void stopMessageProcessing() {
        if (processorClient != null && processorClient.isRunning()) {
            logger.info("Stopping the Service Bus processor...");
            processorClient.close();
            logger.info("Service Bus processor stopped");
        }
    }
    
    public static class ProcessingStatistics {
        private final int totalMessages;
        private final int temperatureMessages;
        private final int cashStatusMessages;
        private final int unknownMessages;
        private final int errors;
        private final boolean running;
        
        public ProcessingStatistics(int totalMessages, int temperatureMessages, int cashStatusMessages,
                                  int unknownMessages, int errors, boolean running) {
            this.totalMessages = totalMessages;
            this.temperatureMessages = temperatureMessages;
            this.cashStatusMessages = cashStatusMessages;
            this.unknownMessages = unknownMessages;
            this.errors = errors;
            this.running = running;
        }
        
        public int getTotalMessages() { return totalMessages; }
        public int getTemperatureMessages() { return temperatureMessages; }
        public int getCashStatusMessages() { return cashStatusMessages; }
        public int getUnknownMessages() { return unknownMessages; }
        public int getErrors() { return errors; }
        public boolean isRunning() { return running; }
    }
}
