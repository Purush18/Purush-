package com.atmmonitor.v3.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonFormat;


@Entity
@Table(name = "CashStatusLogs")
public class CashStatusLogs {
    
   
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "cashlogid")
    private Integer cashlogid;
    
    
    @NotNull
    @Column(name = "connectionDeviceId", length = 50, nullable = false)
    private String connectionDeviceId;
    
   
    @NotNull
    @Column(name = "timestamp", nullable = false)
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS")
    private LocalDateTime timestamp;
    
    
    @Column(name = "notes100")
    private Integer notes100;
    
   
    @Column(name = "notes200")
    private Integer notes200;
    
   
    @Column(name = "notes500")
    private Integer notes500;
    
   
    @Column(name = "totalamount", precision = 19, scale = 2)
    private BigDecimal totalamount;
    
   
    public CashStatusLogs() {
    }
    
   
    public CashStatusLogs(String connectionDeviceId, LocalDateTime timestamp, Integer notes100, 
                         Integer notes200, Integer notes500, BigDecimal totalamount) {
        this.connectionDeviceId = connectionDeviceId;
        this.timestamp = timestamp;
        this.notes100 = notes100;
        this.notes200 = notes200;
        this.notes500 = notes500;
        //this.status = status;
        this.totalamount = totalamount;
    }

   
    public void calculateTotalAmount() {
        BigDecimal total = BigDecimal.ZERO;
        
        if (notes100 != null) {
            total = total.add(new BigDecimal(notes100).multiply(new BigDecimal("100")));
        }
        
        if (notes200 != null) {
            total = total.add(new BigDecimal(notes200).multiply(new BigDecimal("200")));
        }
        
        if (notes500 != null) {
            total = total.add(new BigDecimal(notes500).multiply(new BigDecimal("500")));
        }
        
        this.totalamount = total;
    }

    // Getters and Setters
    
    public Integer getCashlogid() {
        return cashlogid;
    }

    public void setCashlogid(Integer cashlogid) {
        this.cashlogid = cashlogid;
    }

    public String getConnectionDeviceId() {
        return connectionDeviceId;
    }

    public void setConnectionDeviceId(String connectionDeviceId) {
        this.connectionDeviceId = connectionDeviceId;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }

    public Integer getNotes100() {
        return notes100;
    }

    public void setNotes100(Integer notes100) {
        this.notes100 = notes100;
    }

    public Integer getNotes200() {
        return notes200;
    }

    public void setNotes200(Integer notes200) {
        this.notes200 = notes200;
    }

    public Integer getNotes500() {
        return notes500;
    }

    public void setNotes500(Integer notes500) {
        this.notes500 = notes500;
    }

    public BigDecimal getTotalamount() {
        return totalamount;
    }

    public void setTotalamount(BigDecimal totalamount) {
        this.totalamount = totalamount;
    }
    
    
    @Override
    public String toString() {
        return "CashStatusLogs{" +
                "cashlogid=" + cashlogid +
                ", connectionDeviceId='" + connectionDeviceId + '\'' +
                ", timestamp=" + timestamp +
                ", notes100=" + notes100 +
                ", notes200=" + notes200 +
                ", notes500=" + notes500 +
                //", status='" + status + '\'' +
                ", totalamount=" + totalamount +
                '}';
    }
}